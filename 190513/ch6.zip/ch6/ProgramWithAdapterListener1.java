import java.awt.*;
import java.awt.event.*;
class ProgramWithNamedListener1 extends Frame
{  //�ڲ�����Ϊclass���͵���
   private class InnerWindowCloser extends WindowAdapter
   {  public void windowClosing(WindowEvent we)
      {  System.exit(0); }
   }
public ProgramWithNamedListener1()
   {  addWindowListener(new InnerWindowCloser());
      setSize(200,200);
      setVisible(true);
   }
public static void main(String args[])
      {  ProgramWithNamedListener1 p = new ProgramWithNamedListener1(); }
}
