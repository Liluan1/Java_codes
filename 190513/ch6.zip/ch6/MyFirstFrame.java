import java.awt.*;
public class MyFirstFrame extends Frame 
{ 
   private Button quit = new Button("Quit!!!!");         //������
  
   public MyFirstFrame()
   {  super("Test Window????");
      add(quit);
      pack();
      setVisible(true);
   }
   public static void main(String args[])
   {  MyFirstFrame mft = new MyFirstFrame(); }
}

