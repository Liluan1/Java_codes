import java.awt.*;
import java.awt.event.*;
public class MultipleEventTester extends Frame
        implements WindowListener,MouseListener,KeyListener
{  // ���캯��
    public MultipleEventTester()
    {  addWindowListener(this);
        addMouseListener(this);
        addKeyListener(this);
        setSize(400,200);
        setVisible(true);
    }
    // �����¼�������
    public void windowClosing(WindowEvent we)
    {  System.exit(0); }
    public void windowOpened(WindowEvent we)
    {  System.out.println("Window opened "); }
    public void windowIconified(WindowEvent we)
    {  System.out.println("Window iconified " + we); }
    public void windowDeiconified(WindowEvent we)
    {  System.out.println("Window deiconified " + we); }
    public void windowClosed(WindowEvent we)
    {  System.out.println("Window closed " + we); }
    public void windowActivated(WindowEvent we)
    {  System.out.println("Window activated " + we); }
    public void windowDeactivated(WindowEvent we)
    {  System.out.println("Window deactivated " + we); }
    // ����¼�������
    public void mousePressed(MouseEvent me)
    {  System.out.println("Mouse pressed " + me); }
    public void mouseReleased(MouseEvent me)
    {  System.out.println("Mouse released " + me); }
    public void mouseEntered(MouseEvent me)
    {  System.out.println("Mouse entered " + me); }
    public void mouseExited(MouseEvent me)
    {  System.out.println("Mouse exited " + me); }
    public void mouseClicked(MouseEvent me)
    {  System.out.println("Mouse clicked " + me); }
    // �����¼�������
    public void keyPressed(KeyEvent ke)
    {  System.out.println("key pressed " + ke); }
    public void keyReleased(KeyEvent ke)
    {  System.out.println("key released " + ke); }
    public void keyTyped(KeyEvent ke)
    {  System.out.println("key typed " + ke); }


    public static void main(String args[])
    {  MultipleEventTester p = new MultipleEventTester(); }
}

