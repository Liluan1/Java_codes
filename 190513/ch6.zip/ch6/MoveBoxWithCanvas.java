import java.awt.*;
import java.awt.event.*;
public class MoveBoxWithCanvas extends Frame implements ActionListener
{  private Button left  = new Button("Left");
   private Button right = new Button("Right");
   private Button up    = new Button("Up");
   private Button down  = new Button("Down");
   public MoveBoxCanvas drawing = new MoveBoxCanvas();
   public MoveBoxWithCanvas()
   {  super("Moving Box");
      setup();
      left.addActionListener(this);  right.addActionListener(this);
      up.addActionListener(this);   down.addActionListener(this);
      setSize(400,400); show();
   }
   private void setup()
   {  Panel buttons = new Panel();
      buttons.setLayout(new FlowLayout());
      buttons.add(up);   buttons.add(down); 
      buttons.add(left);  buttons.add(right);
      setLayout(new BorderLayout());
      add("South",buttons);
      add("Center",drawing);
   }
   public void actionPerformed(ActionEvent e)
   {  if (e.getSource() == up)
         drawing.moveUp();
      else if (e.getSource() == down)
         drawing.moveDown();
      else if (e.getSource() == left)
         drawing.moveLeft();
      else if (e.getSource() == right)
         drawing.moveRight();
      drawing.repaint();
   }
   public static void main(String args[])
   {  MoveBoxWithCanvas mb = new MoveBoxWithCanvas(); }
}

