//GridLayout��
import java.awt.*;
import java.awt.event.*;
public class ShowGrid extends Frame
{  public ShowGrid()
   {  super("GridLayout example");
      setLayout(new GridLayout(3,0));
      add(new Button("Button 1"));
      add(new Button("Button 2"));
      add(new Button("Button 4fddfgfdgdsfgdfsg"));
      add(new Button("Button 3"));
      add(new Button("Button 5"));
      add(new Button("Button 3"));
      add(new Button("Button 5"));
	  add(new Button("Button 9"));
      addWindowListener(new WindowCloser());
      pack(); setVisible(true);
   }
   public static void main(String args[])
   {  ShowGrid gl = new ShowGrid(); }
}
class WindowCloser extends WindowAdapter{
   public void windowClosing(WindowEvent we)
   {  System.exit(0); }
}
