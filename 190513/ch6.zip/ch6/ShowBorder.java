import java.awt.*;
public class ShowBorder extends Frame
{  public ShowBorder()
   {  super("BorderLayout example");
      setLayout(new BorderLayout());
      add("East", new Button("��"));
      add("West", new Button("��"));
      add("North", new Button(" dfdsf"));
      
     add( new Button("��"));
	     add( new Button("��֪��"));
      add("South", new Button("��"));
	  addWindowListener(new WindowCloser());
      pack(); setVisible(true);
   }
   public static void main(String args[])
   {  ShowBorder bl = new ShowBorder(); }
}
