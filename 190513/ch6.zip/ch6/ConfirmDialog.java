import java.awt.*;
import java.awt.event.*;
public class ConfirmDialog extends Dialog implements ActionListener
{  private Button okay = new Button("Ok");
   private Button cancel = new Button("Cancel");
   private Label  label = new Label("Are you sure?",Label.CENTER);
   public  boolean isOkay = false;
   private class WindowCloser extends WindowAdapter
   {  public void windowClosing(WindowEvent we)
      {  ConfirmDialog.this.isOkay = false;
         ConfirmDialog.this.setVisible(true);
		 hide();
      }
   }
   public ConfirmDialog(Frame parent)
   {  this(parent,"Please confirm","Are you sure?"); }
   public ConfirmDialog(Frame parent,String title,String question)
   {  super(parent,title,true);
      label.setText(question);
      setup();
      okay.addActionListener(this);
      cancel.addActionListener(this);
      addWindowListener(new WindowCloser());
      setResizable(false);
      pack(); setVisible(true);
   }
   private void setup()
   {  Panel buttons = new Panel();
      buttons.setLayout(new FlowLayout());
      buttons.add(okay); buttons.add(cancel);
      setLayout(new BorderLayout());
      add("Center",label);  add("South",buttons);
   }
   public void actionPerformed(ActionEvent ae)
   {  isOkay = (ae.getSource() == okay);
       hide();
   }
}

