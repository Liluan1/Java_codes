import java.awt.Frame;
public class MyFrameTest
{  
   public static void main(String args[])
   {  Frame myFrame = new Frame("My First Frame");
      myFrame.setVisible(true); 
	  //ʹһ��Frame �ɼ�
	  myFrame.setSize(100,200); 
   }
}

