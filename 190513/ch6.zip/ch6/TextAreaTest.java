import java.awt.*;
import java.awt.event.*;
public class TextAreaTest extends Frame implements ActionListener{
   private TextField input = new TextField();
   private TextArea  output = new TextArea();
   private Button add = new Button("Add");
   private Button addLn = new Button("Add + Return");
   private class WindowCloser extends WindowAdapter{
      public void windowClosing(WindowEvent we) {
         System.exit(0); }
   }
   public TextAreaTest(){
      super("TextAreaTest");
      setup();
      add.addActionListener(this);
      addLn.addActionListener(this);
      addWindowListener(new WindowCloser());
      pack(); setVisible(true);
   }
   public void actionPerformed(ActionEvent e) {
      if (e.getSource() == add)
         output.append(input.getText());
      else if (e.getSource() == addLn)
         output.append("\n"+input.getText());
   }
   private void setup(){
      Panel top = new Panel();
      top.setLayout(new BorderLayout());
      top.add("West",add); top.add("Center",input); 
      top.add("East",addLn);
      setLayout(new BorderLayout());
      add("North",top); add("Center",output);
   }
   public static void main(String args[])
   {  TextAreaTest tat = new TextAreaTest(); }
}