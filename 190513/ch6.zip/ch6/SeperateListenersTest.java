import java.awt.*;
import java.awt.event.*;
public class SeperateListenersTest extends Frame
{  private KeyEventHandler keyListener = new KeyEventHandler();
   private WindowCloser windowListener = new WindowCloser();
  
   public SeperateListenersTest()
   {  addKeyListener(keyListener);
   
      addWindowListener(windowListener);
     
      setSize(400,400);
      setVisible(true);
   }
   public static void main(String args[])
   {  SeperateListenersTest p = new SeperateListenersTest(); }
}

class KeyEventHandler implements KeyListener
{  public void keyPressed(KeyEvent ke)
   {  if (ke.getKeyChar() == 'q')
         System.exit(0);
   }
   public void keyReleased(KeyEvent ke)
   { }
   public void keyTyped(KeyEvent ke)
   {  System.out.println("Key Listener: Key pressed: " + ke.getKeyChar());}
}

class WindowCloser1 implements WindowListener
{  public void windowClosing(WindowEvent we)
   {  System.exit(0); }
   public void windowOpened(WindowEvent we)  {  }
   public void windowIconified(WindowEvent we)  {  }
   public void windowDeiconified(WindowEvent we)  {  };
   public void windowClosed(WindowEvent we)   {  }
   public void windowActivated(WindowEvent we)  {  }
   public void windowDeactivated(WindowEvent we) {  }
}
