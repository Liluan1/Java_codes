//<applet code=DrawWithCanvas.class width=200 height=300> 
//</applet> 
import java.applet.*;
import java.awt.*;
public class DrawWithCanvas extends Applet
{  private Button draw = new Button("Draw");
   private DrawCanvas drawing = new DrawCanvas();
   public void init()
   {  Panel buttons = new Panel();
      buttons.setLayout(new FlowLayout());
      buttons.add(draw);
      setLayout(new BorderLayout());
      add("North",buttons);
      add("Center",drawing);
   }
}
//public
 class DrawCanvas extends Canvas
{  public void paint(Graphics g)
   {  for (int i = 12; i < getSize().height; i+=12)
         g.drawString("y location: " + i,10,i);
   }
}

