import java.awt.*;
import java.awt.event.*;
public class TaskList extends Frame implements ActionListener
{  private Button add = new Button("����");
   private Button del = new Button("ɾ��");
   private Button up  = new Button("�������ȼ�");
   private Button down = new Button("�������ȼ�");
   private List list = new List();
   private TextField taskInput = new TextField();
   private Label priorityLabel = new Label("�ı����ȼ�");
   private Label taskLabel = new Label("��������:");
   private class WindowCloser extends WindowAdapter
   {  public void windowClosing(WindowEvent we)
      {  System.exit(0); }
   }
   public TaskList()
{  super("���������");
   setup();
   add.addActionListener(this);
   del.addActionListener(this);
   up.addActionListener(this);
   down.addActionListener(this);
   addWindowListener(new WindowCloser());
   pack();
   setVisible(true);
}

 

 //���°�ť��ķ�Ӧ 
public void actionPerformed(ActionEvent ae)
{  if ((ae.getSource() == add) && (!taskInput.getText().equals("")))
      handleAdd(taskInput.getText().trim());
   else if ((ae.getSource() == del) && (list.getSelectedIndex() >= 0))
      handleDel(list.getSelectedIndex());
   else if ((ae.getSource() == up) && (list.getSelectedIndex() > 0))
      handleIncPriority(list.getSelectedIndex());
   else if ((ae.getSource() == down) && (list.getSelectedIndex() >= 0))
      handleDecPriority(list.getSelectedIndex());
   taskInput.requestFocus();
}

   public static void main(String args[])
   {  TaskList tl = new TaskList(); }

private void setup()
{  Panel buttons = new Panel();
   buttons.setLayout(new FlowLayout());
   buttons.add(add); buttons.add(del);
   Panel priorities = new Panel();
   priorities.setLayout(new FlowLayout());
   priorities.add(up); priorities.add(priorityLabel); priorities.add(down);
   Panel input = new Panel();
   input.setLayout(new BorderLayout());
   input.add("West",taskLabel); input.add("Center",taskInput);
   Panel top = new Panel();
   top.setLayout(new GridLayout(2,1));
   top.add(input); top.add(priorities);
   setLayout(new BorderLayout());
   add("Center",buttons); add("South",list); add("North",top);
}

private void handleAdd(String newTask)
{  list.add(newTask);
   list.select(list.getItemCount()-1);
   taskInput.setText("");
}
private void handleDel(int pos)
{  list.remove(pos);
   list.select(pos);
}

private void handleIncPriority(int pos)
{  String item = list.getItem(pos);
   list.remove(pos);
   list.add(item,pos-1);
   list.select(pos-1);
}

private void handleDecPriority(int pos)
{  if (pos < list.getItemCount()-1)
   {  String item = list.getItem(pos);
      list.remove(pos);
      list.add(item,pos+1);
      list.select(pos+1);
   }
}


}


