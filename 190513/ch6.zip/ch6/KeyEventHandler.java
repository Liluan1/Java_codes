import java.awt.*;
import java.awt.event.*;
public class KeyEventHandler implements KeyListener
{  public void keyPressed(KeyEvent ke)
   {  if (ke.getKeyChar() == 'q')
         System.exit(0);
   }
   public void keyReleased(KeyEvent ke)
   { }
   public void keyTyped(KeyEvent ke)
   {  System.out.println("Key Listener: Key pressed: " + ke.getKeyChar());}
}


