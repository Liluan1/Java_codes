import java.awt.*;
import java.awt.event.*;
public class ConfirmDialogsign extends Dialog implements ActionListener
{  private Button okay = new Button("Ok");
   private Button cancel = new Button("Cancel");
   private Label  label = new Label("Are you sure?",Label.CENTER);
   public  boolean isOkay = false;
   private StopSign stop = new StopSign();
   private class WindowCloser extends WindowAdapter
   {  public void windowClosing(WindowEvent we)
      {  ConfirmDialogsign.this.isOkay = false;
         ConfirmDialogsign.this.hide();
      }
   }
   public ConfirmDialogsign(Frame parent)
   {  this(parent,"Please confirm","Are you sure?"); }
   public ConfirmDialogsign(Frame parent,String title,String question)
   {  super(parent,title,true);
      label.setText(question);
      setup();
      okay.addActionListener(this);
      cancel.addActionListener(this);
      addWindowListener(new WindowCloser());
      setResizable(false);
      pack(); show();
   }
   private void setup()
   {  Panel buttons = new Panel();
      buttons.setLayout(new FlowLayout());
      buttons.add(okay); buttons.add(cancel);
      setLayout(new BorderLayout());
      add("Center",label);  add("South",buttons);
      add("West",stop);
   }
   public void actionPerformed(ActionEvent ae)
   {  isOkay = (ae.getSource() == okay);
      hide();
   }
}

