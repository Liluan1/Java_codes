import java.awt.*;
import java.awt.event.*;
public class CountDown
{  ActionListener listener = null;
   Object source = null;
   int maxCount = 10;
   public CountDown(Object _source,int _maxCount)
   {  maxCount = _maxCount;
      source = _source;
   }
   public void addActionListener(ActionListener newListener)
   {  listener = AWTEventMulticaster.add(listener,newListener); }
   public void removeActionListener(ActionListener oldListener)
   {  listener = AWTEventMulticaster.remove(listener,oldListener); }
   public void startCounting()
   {  if (listener != null)
      {  for (int i = maxCount; i >= 0; i--)
            System.out.println("i: " + i);
         System.out.println("Done. Generating event now ...");
         listener.actionPerformed(new ActionEvent(source,
               ActionEvent.ACTION_PERFORMED,"CountDown"));
      }
   }
}

