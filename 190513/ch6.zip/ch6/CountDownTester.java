import java.awt.*;
import java.awt.event.*;
public class CountDownTester extends Frame implements ActionListener
{  private Button start = new Button("Start");
   private Button show = new Button("Show");
   private TextField display = new TextField(25);
   private CountDown count = new CountDown(show,25);
   private class WindowCloser extends WindowAdapter
   {  public void windowClosing(WindowEvent we)
      {  System.exit(0); }
   }
   public CountDownTester()
   {  super("CountDown Tester");
      setLayout(new FlowLayout());
      add(start); 
      add(show); 
      add(display);
      show.addActionListener(this);
      start.addActionListener(this);
      count.addActionListener(this);
      addWindowListener(new WindowCloser());
      pack(); setVisible(true);
   }
   public void actionPerformed(ActionEvent e)
   {  if (e.getSource() == start)
         count.startCounting();
      else if (e.getSource() == show)
         display.setText("Event came from: " + e.getActionCommand());
   }
   public static void main(String args[])
   {  CountDownTester c = new CountDownTester(); }
}

