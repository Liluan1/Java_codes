import java.awt.*;
import java.awt.event.*;
public class GraphicsTest extends Frame
{  private class WindowCloser extends WindowAdapter
   {  public void windowClosing(WindowEvent we)
      {  System.exit(0); }
   }
   public GraphicsTest()
   {  super("Graphics Test");
      setSize(400,400); setVisible(true);
      addWindowListener(new WindowCloser());
   }
   public void paint(Graphics g)
   {  g.setColor(Color.black);  g.drawOval(100,4,30,40);
      g.setColor(Color.red);    g.drawRect(40,50,50,60);
      g.setColor(Color.blue);   g.drawString("Hello World",80,40);
      g.setColor(Color.green);  g.fillOval(120,100,40,40);
      g.setColor(Color.pink);   g.fillArc(30,120,70,70,60,120);
      g.setColor(Color.gray);   g.fill3DRect(90,120,20,20,true);
      g.setColor(Color.black);  
      g.drawOval(120,100,40,40);
      g.drawArc(30,120,70,70,60,120); 
   }
   public static void main(String args[])
   {  GraphicsTest gt = new GraphicsTest(); }
}
