
//import java.applet.*;
import java.awt.*;
class TextFiled_Button extends Frame{
	  TextFiled_Button(){
	  Panel buttons = new Panel();
      buttons.setLayout(new FlowLayout());
      buttons.add(new Button("ȷ��"));
      buttons.add(new Button("ȡ��"));
      Panel textGrid = new Panel();
      textGrid.setLayout(new GridLayout(2,2));
      for (int i = 0; i < 4; i++)
         textGrid.add(new TextField(4));
      setLayout(new BorderLayout());
      add("North",buttons);
      add("South",textGrid);
      pack();
      show();
    };
  
  }
public class PanelExample 
{  public static void  main(String[] args){
	
   TextFiled_Button tb=new TextFiled_Button();
}                              
}
