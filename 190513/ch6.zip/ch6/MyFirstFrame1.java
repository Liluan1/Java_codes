import java.awt.*;
import java.awt.event.*;	/* Import components�� interfaces�� and events */
public class MyFirstFrame1 extends Frame 
             implements ActionListener	/* Class of type Frame and ActionListener */
{ private Button quit = new Button("Quit");	/* Define GUI components as fields */
public MyFirstFrame1()     /* Constructor to initialize frame */
   {  super("Test Window");      
      add(quit);
      pack();	//�����˴��ڵĴ�С�����ʺ������������ѡ��С�Ͳ��֡�
      setVisible(true);
      quit.addActionListener(this);
   }	/* Register button as action event source and tie it to event handler. 
          Here it is this class itself. */
    public void actionPerformed(ActionEvent e)	/* Specify what to do with action events */ 
   { System.out.println("Ҫ�˳���");  
	  dispose();
      System.exit(0);                /* Quits program�� returns to operating system */
   }	
public static void main(String args[])   	/* Make program executable */ 

   { MyFirstFrame1 mf = new MyFirstFrame1();}
}
