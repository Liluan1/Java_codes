import java.awt.*;
import java.awt.event.*;
public class ProgramWithAdapterListener extends Frame 
{  private WindowCloser listener = new WindowCloser();
   public ProgramWithAdapterListener()
   { addWindowListener(listener);
      setSize(200,200);
      setVisible(true);
   }
   public static void main(String args[])
   {  ProgramWithAdapterListener p = new ProgramWithAdapterListener(); }
}

 class WindowCloser extends WindowAdapter{
// class WindowCloser extends WindowCloser1{
   public void windowClosing(WindowEvent we)
   { System.out.println("Ҫ�˳���");
	   System.exit(0); }
/*   public void windowIconified(WindowEvent we)  { 
      System.out.println("���ڴ���");

   }
*/
}
