import java.awt.*;
public class ShowFlow extends Frame
{  public ShowFlow()
   {  super("FlowLayout example");
      setSize(500,300);
	  setLayout(new FlowLayout());
      add(new Button("Button 1"));
      add(new Button("Button 2"));
      add(new Button("Button 3fgfgfg"));
      add(new Button("Button 4"));  
      add(new Button("Button 5"));
      addWindowListener(new WindowCloser());
	 
  //    pack(); 
	  setVisible(true);
   }
   public static void main(String args[])
   {  ShowFlow fl = new ShowFlow(); }
}
