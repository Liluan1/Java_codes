import java.awt.*;
import java.awt.event.*;
public class ConfirmDialog extends Dialog implements ActionListener
{
	private Button yes=new Button("Yes");
	private Button no=new Button("No");
	private Label label=new Label("",1);
	public boolean isOkay=false;
/*	public ConfirmDialog(Frame parent){
		this(parent,"Please Confirm","Are you sure");
	}*/
	public ConfirmDialog(Frame parent,String title,String question){
		super(parent,title,true);
		label.setText(question);
		setup();
		yes.addActionListener(this);
		no.addActionListener(this);
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent we){
				ConfirmDialog.this.isOkay=false;
				ConfirmDialog.this.setVisible(false);
			}
		});
		setResizable(false);
		pack();setVisible(true);
	}

	private void setup(){
		Panel buttons=new Panel();
		buttons.setLayout(new FlowLayout());
		buttons.add(yes);buttons.add(no);
		setLayout(new BorderLayout());
		add("Center",label); add("South",buttons);
	}

	public void actionPerformed(ActionEvent ae){
		isOkay=(ae.getSource()==yes);
		setVisible(false);
	}
};