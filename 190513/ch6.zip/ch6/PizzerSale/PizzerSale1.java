import java.awt.*;
import java.util.Formatter;
import java.awt.event.*;
public class PizzerSale1 extends Frame{// implements ActionListener 
	private List sizeList=new List();
	private List styleList=new List();
	private List toppingList=new List();
	private double array[][]=new double[8][8];
	private double sum;
	private int start,end;
	private int index2=0,index3=0,index4=0,index5=0,index6=0,index7=0;
	private Label sizes=new Label("Sizes");
	private Label styles=new Label("Styles");
	private Label toppings=new Label("Toppings");
	private Label pizzer=new Label("Pizzeria Juno",1);
	private Label click=new Label("Click to complete order");
	private Label or=new Label("or");
	private TextArea list=new TextArea();
	private Button ringUp=new Button("Total Price");
	private Button quit=new Button("Quit");
	private Button tryOnceMore=new Button("Clean All & Try Again");
	private class WindowCloser extends WindowAdapter{
		public void windowClosing(WindowEvent we){
			System.exit(0);
		}
	};
	public PizzerSale1(){
		super("Pizzeria Juno Register");
		setBackground(Color.lightGray);
		setForeground(Color.blue);

		sizeList.add("Extra Large",0);sizeList.add("Large",1);
		sizeList.add("Medium",2);sizeList.add("Small",3);

        styleList.add("Deep Dish",0);styleList.add("Regular",1);
		styleList.add("Thin Crust",2);styleList.add("Chicago",3);

		toppingList.add("Cheese",0);toppingList.add("Tomato",1);
		toppingList.add("Peppers",2);toppingList.add("Peperoni",3);
		toppingList.add("vegetable",4);toppingList.add("sala",5);

		sizes.setFont(new Font("Sizes",Font.BOLD,16));
		styles.setFont(new Font("Styles",Font.BOLD,16));
		toppings.setFont(new Font("Toppings",Font.BOLD,16));
		pizzer.setFont(new Font("Pizzeria Juno",Font.ITALIC,24));

		setup();
		list.setEditable(false);
		ringUp.addActionListener(this);
		quit.addActionListener(this);
		tryOnceMore.addActionListener(this);
		sizeList.addActionListener(this);
		styleList.addActionListener(this);
		toppingList.addActionListener(this);
		addWindowListener(new WindowCloser());
		pack();setVisible(true);
	}
  
    public double sumTotal(){
		sum=0.00;
		for (int i=0; i<array.length; i++){
			for (int j=0; j<array.length; j++){
				sum +=array[i][j];
		       }
		}	
		return sum;
	}

	public  void  insertZero(int h){
		for (int i=h; i<array.length; i++){
			for (int j=0; j<array.length; j++){
				array[i][j]=0.00;
			}
		}
	}

	public void actionPerformed(ActionEvent ae){
		if (ae.getSource()==quit){
			ConfirmDialog exit=new ConfirmDialog(
				this,"Confirm Exit","Do you really want to exit?");
			if (exit.isOkay){
			   System.exit(0);
			}
		}else if (ae.getSource()==sizeList){
			insertZero(0);
			switch(sizeList.getSelectedIndex()){
              case 0: array[0][0]=10.00;
			  list.replaceRange(sizeList.getSelectedItem()+"  Pizza, ",0,list.getSelectionEnd());
			  break;
			  case 1: array[0][0]=8.00;
			  list.replaceRange(sizeList.getSelectedItem()+"  Pizza, ",0,list.getSelectionEnd());
			  break;
			  case 2: array[0][0]=5.00;
			  list.replaceRange(sizeList.getSelectedItem()+"  Pizza, ",0,list.getSelectionEnd());
			  break;
			  case 3: array[0][0]=3.00;
			  list.replaceRange(sizeList.getSelectedItem()+"  Pizza, ",0,list.getSelectionEnd());
			  break;
			}
              start=list.getSelectionEnd();
		}
		else if (ae.getSource()==styleList){ 
			insertZero(1);
			switch (styleList.getSelectedIndex()){
			case 0: array[1][0]=4.00;
			list.replaceRange(styleList.getSelectedItem()+"  style\n",start,list.getSelectionEnd());
			break;
			case 1: array[1][0]=3.00;
			list.replaceRange(styleList.getSelectedItem()+"  style\n",start,list.getSelectionEnd());
			break;
			case 2: array[1][0]=2.00;
			list.replaceRange(styleList.getSelectedItem()+"  style\n",start,list.getSelectionEnd());
			break;
			case 3: array[1][0]=1.00;
			list.replaceRange(styleList.getSelectedItem()+"  style\n",start,list.getSelectionEnd());
			break;
			}
		}   
		else if (ae.getSource()==toppingList){ 
	 		switch (toppingList.getSelectedIndex()){
			case 0: array[2][index2++]=2.50;
			list.insert("\t\t+"+toppingList.getSelectedItem()+"\n",list.getSelectionStart());
			break;
			case 1: array[3][index3++]=1.80;
			list.insert("\t\t+"+toppingList.getSelectedItem()+"\n",list.getSelectionStart());
			break;
			case 2: array[4][index4++]=1.50;
			list.insert("\t\t+"+toppingList.getSelectedItem()+"\n",list.getSelectionStart());
			break;
			case 3: array[5][index5++]=1.20;
			list.insert("\t\t+"+toppingList.getSelectedItem()+"\n",list.getSelectionStart());
			break;
			case 4: array[6][index6++]=1.10;
			list.insert("\t\t+"+toppingList.getSelectedItem()+"\n",list.getSelectionStart());
			break;
			case 5: array[7][index7++]=1.00;
			list.insert("\t\t+"+toppingList.getSelectedItem()+"\n",list.getSelectionStart());
			break;
			}
		}
		else if (ae.getSource()==ringUp){
			Formatter f=new Formatter();
			list.append("\t\tToal: $"+f.format("%.2f",sumTotal()));
            end=list.getSelectionEnd();
		}	
		else if (ae.getSource()==tryOnceMore){
			list.replaceRange("",0,end);
			insertZero(0);
		}
	}

	private void setup(){
		Panel label=new Panel();
		label.setLayout(new GridLayout(1,3));
		label.add(sizes);label.add(styles);label.add(toppings);

		Panel top=new Panel();
		top.setLayout(new BorderLayout());
		top.add("North",pizzer); top.add("Center",label);

		Panel textList=new Panel();
		textList.setLayout(new GridLayout(1,3));
		textList.add(sizeList); textList.add(styleList); textList.add(toppingList);

		Panel itemChoose=new Panel();
		itemChoose.setLayout(new BorderLayout());
		itemChoose.add("North",top); itemChoose.add("Center",textList);

		Panel buttons=new Panel();
		buttons.setLayout(new FlowLayout());
		buttons.add(click); buttons.add(ringUp); buttons.add(tryOnceMore);
		buttons.add(or);buttons.add(quit);

		setLayout(new BorderLayout());
		add("North",itemChoose); add("Center",list); add("South",buttons);
	}
    public static void main(String args[]){
		PizzerSale1 p=new PizzerSale1();	
	}
};