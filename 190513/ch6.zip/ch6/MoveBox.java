import java.awt.*;
import java.awt.event.*;
public class MoveBox extends Frame implements ActionListener
{  private final int WIDTH = 30,HEIGHT = 20,INC = 4;
   private Button left  = new Button("Left");
   private Button right = new Button("Right");
   private Button up    = new Button("Up");
   private Button down  = new Button("Down");
   private int x = 50,y = 50;
   Image bird= Toolkit.getDefaultToolkit().getImage("./bird.bmp");
   public MoveBox()
   {  super("Moving Box");
      setup();
      left.addActionListener(this); right.addActionListener(this);
      up.addActionListener(this);   down.addActionListener(this);
      setSize(400,400); show();
   }
   private void setup()
   {  Panel buttons = new Panel();
      buttons.setLayout(new FlowLayout());
      buttons.add(up); buttons.add(down); 
      buttons.add(left); buttons.add(right);
      setLayout(new BorderLayout());
      add("South",buttons);
   }
   public void paint(Graphics g)
   { // g.fillRect(x,y,WIDTH,HEIGHT); 
      g.drawImage(bird,x,y,50,50,this);}
   public void moveUp()
   {  y -= INC; }
   public void moveDown()
   {  y += INC; }
   public void moveLeft()
   {  x -= INC; }
   public void moveRight()
   {  x += INC; }
   public void actionPerformed(ActionEvent e)
   {  if (e.getSource() == up)
         moveUp();
      else if (e.getSource() == down)
         moveDown();
      else if (e.getSource() == left)
         moveLeft();
      else if (e.getSource() == right)
         moveRight();
     repaint();
   }
   public static void main(String args[])
   {  MoveBox mb = new MoveBox(); }
}

