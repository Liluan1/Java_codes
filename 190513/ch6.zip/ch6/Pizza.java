import java.awt.*;
import java.awt.event.*;
public class Pizza extends Frame implements ActionListener
{  private Button ring = new Button("Ring up");
   private Button quit = new Button("Quit");
   
   private List list1 = new List();
   private List list2 = new List();
   private List list3 = new List(4,true);
   
   private TextArea taskInput = new TextArea();
  
   private Label pizza = new Label("Pizza Pizza");
   private Label size = new Label("Sizes");
   private Label st = new Label("Styles");
   private Label top = new Label("Toppings");
   private Label click = new Label("Click dfjjjjjjjjj");
   private Label or = new Label("Or");
  
   private class WindowCloser extends WindowAdapter
   {  public void windowClosing(WindowEvent we)
      {  System.exit(0); }
   }
   public Pizza()
{  super("Pizza Pzziaa  pppppppp");
   setup();
   /*add.addActionListener(this);
   del.addActionListener(this);
   up.addActionListener(this);
   down.addActionListener(this);
   */
   addWindowListener(new WindowCloser());
   pack();
   show();
}

   
 //���°�ť��ķ�Ӧ 
public void actionPerformed(ActionEvent ae)
{
	/*if ((ae.getSource() == add) && (!taskInput.getText().equals("")))
      handleAdd(taskInput.getText().trim());
   else if ((ae.getSource() == del) && (list.getSelectedIndex() >= 0))
      handleDel(list.getSelectedIndex());
   else if ((ae.getSource() == up) && (list.getSelectedIndex() > 0))
      handleIncPriority(list.getSelectedIndex());
   else if ((ae.getSource() == down) && (list.getSelectedIndex() >= 0))
      handleDecPriority(list.getSelectedIndex());
   taskInput.requestFocus();
   */
}

   public static void main(String args[])
   {  Pizza tl = new Pizza(); }

private void setup()
{  Panel b = new Panel();
   b.setLayout(new GridLayout(1,3));
   b.add(size); b.add(st);b.add(top);

   Panel d = new Panel();
   d.setLayout(new BorderLayout());
  d.add("Center",pizza); d.add("South",b); 

   Panel c = new Panel();
   c.setLayout(new GridLayout(1,3));
   c.add(list1); c.add(list2); c.add(list3); 
 
   Panel e = new Panel();
   e.setLayout(new BorderLayout());
  e.add("Center",d); d.add("South",c);

  Panel g = new Panel();
  g.setLayout(new FlowLayout());
  g.add(click); g.add(ring);
  g.add(or); g.add(quit);

  
   setLayout(new BorderLayout());
   add("Center",taskInput); add("South",g); add("North",e);

}


}


