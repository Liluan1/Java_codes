import java.awt.*;
public class MoveBoxCanvas extends Canvas
{  private final int WIDTH = 30,HEIGHT = 20,INC = 4;
   private int x = 50,y = 50;
   public void paint(Graphics g)
   {  g.fillRect(x,y,WIDTH,HEIGHT); 
      g.drawRect(0,0,getSize().width-1,getSize().height-1);
   }
   public void moveUp()
   {  if (y > 0)
         y -= INC;
      else
         y = getSize().height - INC;
   }
   public void moveDown()
   {  if (y < getSize().height - INC)
         y += INC;
      else
         y = 0;
   }
   public void moveLeft()
   {  if (x > 0)
         x -= INC;
      else
         x = getSize().width - INC;
   }
   public void moveRight()
   {  if (x < getSize().width - INC)
         x += INC;
      else
         x = 0;
   }
}

