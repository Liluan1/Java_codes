import java.awt.*;
import java.awt.event.*;
public class FontExample extends Frame
{  private static final String[] FONTS = 
       {"Dialog","DialogInput","Monospaced","Serif","SansSerif"};
   private static final String TEXT = "A logical font example";
   public FontExample()
   {  super("Font Examples");
      setSize(300,300); 
      setVisible(true); 
   }
   public void paint(Graphics g)
   {  for (int i = 0; i < FONTS.length; i++)
      {   g.setFont(new Font(FONTS[i],Font.PLAIN,12));
          g.drawString(FONTS[i] + " (plain): " + TEXT,10,20*i + 40);
      }
      for (int i = 0; i < FONTS.length; i++)
      {  g.setFont(new Font(FONTS[i],Font.BOLD + Font.ITALIC,14));
         g.drawString(FONTS[i] + "(bold,italics): " + TEXT,10,20*i + 180);
      }
   }
   public static void main(String args[])
   {  FontExample fe = new FontExample(); }
}

